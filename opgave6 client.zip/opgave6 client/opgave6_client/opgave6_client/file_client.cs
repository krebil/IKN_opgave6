﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace tcp
{
    class file_client
    {
        /// <summary>
        /// The PORT.
        /// </summary>
        const int PORT = 9000;
        /// <summary>
        /// The BUFSIZE.
        /// </summary>
        const int BUFSIZE = 1000;

        
        private file_client(string[] args)
        {
			TcpClient client = new TcpClient();
			string ip;
			string fileName;
			string path;
            

			if (args.Length > 1)
			{
				ip = args[0];
                fileName = args[1];
			}
			else
			{
				Console.WriteLine("no arguments found, using standard ip and path");
				ip = "10.0.0.1";
				fileName = "Data.txt";
			}
			path = "../../img/" + fileName;

            

            //changeing path if file exists
            if (File.Exists(path))
            {
				path += DateTime.Now.Date.ToShortDateString().Replace('/', ':') + ":" + DateTime.Now.ToShortTimeString().Replace('/', ':');
            }
			client.Connect(ip, PORT);
			var stream = client.GetStream();

			Console.WriteLine("Requesting file: " + fileName);
			sendFileName(fileName, stream);

			Console.WriteLine("trying to fetch file...");
			receiveFile(path, stream);
			Console.WriteLine("file received!");
            
			stream.Close();
			client.Close();
        }

		private void sendFileName(string fileName,NetworkStream io)
		{
			var bytes = Encoding.UTF8.GetBytes(fileName);

			io.Write(bytes, 0, bytes.Length);
		}
        private void receiveFile(String path, NetworkStream io)
        {
			

			byte[] data = new byte[BUFSIZE];
			int i = 0;
            // get file size
			while(i<1)
			{
				io.Read(data, 0, 4);
				i++;
			}
			int fileSize = BitConverter.ToInt32(data, 0);
			Console.WriteLine("File size: " + fileSize + " Bytes");
			if(fileSize == 0)
			{
				Console.WriteLine("file is empty or missing, aborting");
			}

			FileStream fileStream = File.OpenWrite(path);

            //get file
			data = new byte[fileSize + 4];
			while((i = io.Read(data,0,fileSize)) > 0)
			{
				fileStream.Write(data, 0, fileSize);
			}
			fileStream.Close();         
        }

        /// <summary>
        /// The entry point of the program, where the program control starts and ends.
        /// </summary>
        /// <param name='args'>
        /// The command-line arguments.
        /// </param>
        public static void Main(string[] args)
        {
            Console.WriteLine("Client starts...");
            var client = new file_client(args);
        }
    }
}
